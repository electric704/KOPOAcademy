﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_011_Data_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("float 최소값: {0} ~ float 최대값: {1}", float.MinValue, float.MaxValue);
            Console.WriteLine("double 최소값: {0} ~ double 최대값: {1}", double.MinValue, double.MaxValue);
            Console.WriteLine("decimal 최소값: {0} ~ decimal 최대값: {1}", decimal.MinValue, decimal.MaxValue);
        }
    }
}