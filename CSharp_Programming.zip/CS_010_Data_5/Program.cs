﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_010_Data_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float   f = 0.12345678912345678901234567890f;
            double  d = 0.12345678912345678901234567890;
            decimal m = 0.12345678912345678901234567890m;

            Console.WriteLine("float    f = {0}", f);
            Console.WriteLine("double   d = {0}", d);
            Console.WriteLine("decimal  m = {0}", m);
        }
    }
}
