﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_002_ReadWrite
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("한 줄 출력");

            Console.Write("1");
            Console.Write("2");
            Console.Write("3");

            Console.WriteLine("*");
            Console.WriteLine("**");
            Console.WriteLine("***");

            Console.WriteLine("{0} + {1} = {2}", 11, 22, 33);

            Console.WriteLine("  *  ");
            Console.WriteLine(" *** ");
            Console.WriteLine("*****");
        }
    }
}
