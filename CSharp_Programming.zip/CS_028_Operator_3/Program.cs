﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_028_Operator_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");
            Console.WriteLine("Helow" + "World");

            Console.WriteLine();

            Console.WriteLine("a = {0}", 100);
            Console.WriteLine("a = " + 100);

            Console.WriteLine();

            Console.WriteLine("Number: " + 1 + 2);
            Console.WriteLine("Number: " + (1 + 2));
        }
    }
}
