﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_014_Data_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char a = 'A';
            int n = a;

            Console.WriteLine("문자: {0}", a);
            Console.WriteLine("아스키 코드 값: {0}", n);
        }
    }
}
