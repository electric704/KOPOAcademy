﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_062_Array_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numArr = new int[3];

            numArr[0] = 0;
            numArr[1] = 1;
            numArr[2] = 2;

            Console.WriteLine(numArr[0]);
            Console.WriteLine(numArr[1]);
            Console.WriteLine(numArr[2]);
        }
    }
}
