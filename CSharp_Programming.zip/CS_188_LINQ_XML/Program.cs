﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* ---------- ---------- ---------- ---------- ----------
- Proj: CS_188_LINQ_XML
- Desc: XML을 LINQ로 제어
---------- ---------- ---------- ---------- ---------- */
namespace CS_188_LINQ_XML {
    class Program {
        static void Main(string[] args) {
            // 작성중
        }
    }
}
