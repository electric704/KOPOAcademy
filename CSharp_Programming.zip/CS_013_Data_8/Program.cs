﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_013_Data_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char a = 'A';
            char b = 'P';
            char c = 'P';
            char d = 'L';
            char e = 'E';
            Console.WriteLine("{0}{1}{2}{3}{4}", a, b, c, d, e);

            string s = "APPLE";
            Console.WriteLine(s);
        }
    }
}
